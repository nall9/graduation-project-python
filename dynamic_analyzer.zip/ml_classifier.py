import os
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import joblib
from typing import Dict, Any, List
import logging

class MLClassifier:
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self.logger = self._setup_logger()
        self.model_path = "models/malware_classifier.joblib"
        self.scaler_path = "models/scaler.joblib"
        
        # Create models directory if it doesn't exist
        if not os.path.exists("models"):
            os.makedirs("models")
            
        # Load or train the model
        self._initialize_model()
        
    def _setup_logger(self) -> logging.Logger:
        """Setup logging for ML classifier"""
        logger = logging.getLogger('MLClassifier')
        logger.setLevel(logging.INFO)
        
        if not os.path.exists('logs'):
            os.makedirs('logs')
            
        file_handler = logging.FileHandler('logs/ml_classifier.log')
        file_handler.setLevel(logging.INFO)
        
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)
        
        logger.addHandler(file_handler)
        return logger
        
    def _initialize_model(self):
        """Initialize or load the ML model"""
        try:
            if os.path.exists(self.model_path) and os.path.exists(self.scaler_path):
                self.model = joblib.load(self.model_path)
                self.scaler = joblib.load(self.scaler_path)
                self.logger.info("Loaded existing model and scaler")
            else:
                self._train_model()
        except Exception as e:
            self.logger.error(f"Error initializing model: {str(e)}")
            self._train_model()
            
    def _train_model(self):
        """Train a new model with sample data"""
        try:
            # Create sample data for demonstration
            # In a real implementation, you would use actual malware samples
            X = np.random.rand(100, 10)  # 100 samples, 10 features
            y = np.random.randint(0, 2, 100)  # Binary classification
            
            # Scale the features
            X_scaled = self.scaler.fit_transform(X)
            
            # Train the model
            self.model = RandomForestClassifier(n_estimators=100, random_state=42)
            self.model.fit(X_scaled, y)
            
            # Save the model and scaler
            joblib.dump(self.model, self.model_path)
            joblib.dump(self.scaler, self.scaler_path)
            
            self.logger.info("Trained and saved new model")
            
        except Exception as e:
            self.logger.error(f"Error training model: {str(e)}")
            raise
            
    def _extract_features(self, file_path: str) -> np.ndarray:
        """Extract features from the file for classification"""
        try:
            # This is a simplified feature extraction
            # In a real implementation, you would extract meaningful features
            features = []
            
            # File size
            features.append(os.path.getsize(file_path))
            
            # File entropy (simplified)
            with open(file_path, 'rb') as f:
                data = f.read()
                if data:
                    entropy = 0
                    for x in range(256):
                        p_x = float(data.count(x))/len(data)
                        if p_x > 0:
                            entropy += -p_x * np.log2(p_x)
                    features.append(entropy)
                else:
                    features.append(0)
                    
            # Add more features as needed
            # For demonstration, we'll pad with random values
            while len(features) < 10:
                features.append(np.random.rand())
                
            return np.array(features).reshape(1, -1)
            
        except Exception as e:
            self.logger.error(f"Error extracting features: {str(e)}")
            return np.zeros((1, 10))
            
    def classify(self, file_path: str) -> Dict[str, Any]:
        """Classify the given file as malware or benign"""
        results = {
            'prediction': None,
            'probability': None,
            'features': None,
            'error': None
        }
        
        try:
            # Extract features
            features = self._extract_features(file_path)
            results['features'] = features.tolist()
            
            # Scale features
            features_scaled = self.scaler.transform(features)
            
            # Make prediction
            prediction = self.model.predict(features_scaled)[0]
            probability = self.model.predict_proba(features_scaled)[0]
            
            results['prediction'] = 'malware' if prediction == 1 else 'benign'
            results['probability'] = float(probability[1])  # Probability of being malware
            
        except Exception as e:
            self.logger.error(f"Error during classification: {str(e)}")
            results['error'] = str(e)
            
        return results
        
    def update_model(self, new_data: List[Dict[str, Any]]):
        """Update the model with new training data"""
        try:
            # Extract features and labels from new data
            X_new = np.array([d['features'] for d in new_data])
            y_new = np.array([1 if d['label'] == 'malware' else 0 for d in new_data])
            
            # Scale new features
            X_new_scaled = self.scaler.transform(X_new)
            
            # Update the model
            self.model.fit(X_new_scaled, y_new)
            
            # Save the updated model
            joblib.dump(self.model, self.model_path)
            
            self.logger.info("Model updated successfully")
            
        except Exception as e:
            self.logger.error(f"Error updating model: {str(e)}")
            raise 